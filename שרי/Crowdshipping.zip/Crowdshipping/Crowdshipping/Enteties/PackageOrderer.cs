﻿namespace Crowdshipping.Enteties
{
    public class PackageOrderer
    {
        public int OrdererID { get; set; }
        public string FullName { get; set; }
        public string ContactPhone { get; set; }
        public string Email { get; set; }
        public string HomeAddress { get; set; }
        public string DeliveryPreferences { get; set; }
        public string Status { get; set; }
    }
}
